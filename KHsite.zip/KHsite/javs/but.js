const heart = document.querySelector(".heart")
heart.onclick = () => heart.classList.toggle("clicked")